﻿namespace Hanoi
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btn_StopRun = new System.Windows.Forms.Button();
            this.btn_Next = new System.Windows.Forms.Button();
            this.btn_Run = new System.Windows.Forms.Button();
            this.btn_StepBack = new System.Windows.Forms.Button();
            this.btn_BackToStart = new System.Windows.Forms.Button();
            this.btn_RunBack = new System.Windows.Forms.Button();
            this.btn_CreateBoard = new System.Windows.Forms.Button();
            this.txtbox_NumDiscs = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_Range = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.trkbar_Speed = new System.Windows.Forms.TrackBar();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.trkbar_Speed)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_StopRun
            // 
            this.btn_StopRun.BackColor = System.Drawing.Color.SkyBlue;
            this.btn_StopRun.Enabled = false;
            this.btn_StopRun.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btn_StopRun.Location = new System.Drawing.Point(337, 12);
            this.btn_StopRun.Name = "btn_StopRun";
            this.btn_StopRun.Size = new System.Drawing.Size(79, 65);
            this.btn_StopRun.TabIndex = 0;
            this.btn_StopRun.Text = "| |";
            this.btn_StopRun.UseVisualStyleBackColor = false;
            this.btn_StopRun.Click += new System.EventHandler(this.btn_StopRun_Click);
            // 
            // btn_Next
            // 
            this.btn_Next.BackColor = System.Drawing.Color.LightGreen;
            this.btn_Next.Enabled = false;
            this.btn_Next.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btn_Next.Location = new System.Drawing.Point(446, 12);
            this.btn_Next.Name = "btn_Next";
            this.btn_Next.Size = new System.Drawing.Size(79, 65);
            this.btn_Next.TabIndex = 1;
            this.btn_Next.Text = ">";
            this.btn_Next.UseVisualStyleBackColor = false;
            this.btn_Next.Click += new System.EventHandler(this.btn_Next_Click);
            // 
            // btn_Run
            // 
            this.btn_Run.BackColor = System.Drawing.Color.SpringGreen;
            this.btn_Run.Enabled = false;
            this.btn_Run.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btn_Run.Location = new System.Drawing.Point(549, 12);
            this.btn_Run.Name = "btn_Run";
            this.btn_Run.Size = new System.Drawing.Size(79, 65);
            this.btn_Run.TabIndex = 2;
            this.btn_Run.Text = ">>";
            this.btn_Run.UseVisualStyleBackColor = false;
            this.btn_Run.Click += new System.EventHandler(this.btn_Run_Click);
            // 
            // btn_StepBack
            // 
            this.btn_StepBack.BackColor = System.Drawing.Color.SandyBrown;
            this.btn_StepBack.Enabled = false;
            this.btn_StepBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btn_StepBack.Location = new System.Drawing.Point(228, 12);
            this.btn_StepBack.Name = "btn_StepBack";
            this.btn_StepBack.Size = new System.Drawing.Size(79, 65);
            this.btn_StepBack.TabIndex = 3;
            this.btn_StepBack.Text = "<";
            this.btn_StepBack.UseVisualStyleBackColor = false;
            this.btn_StepBack.Click += new System.EventHandler(this.btn_StepBack_Click);
            // 
            // btn_BackToStart
            // 
            this.btn_BackToStart.BackColor = System.Drawing.Color.Red;
            this.btn_BackToStart.Enabled = false;
            this.btn_BackToStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btn_BackToStart.Location = new System.Drawing.Point(12, 12);
            this.btn_BackToStart.Name = "btn_BackToStart";
            this.btn_BackToStart.Size = new System.Drawing.Size(79, 65);
            this.btn_BackToStart.TabIndex = 4;
            this.btn_BackToStart.Text = "|<";
            this.btn_BackToStart.UseVisualStyleBackColor = false;
            this.btn_BackToStart.Click += new System.EventHandler(this.btn_BackToStart_Click);
            // 
            // btn_RunBack
            // 
            this.btn_RunBack.BackColor = System.Drawing.Color.DarkOrange;
            this.btn_RunBack.Enabled = false;
            this.btn_RunBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btn_RunBack.Location = new System.Drawing.Point(119, 12);
            this.btn_RunBack.Name = "btn_RunBack";
            this.btn_RunBack.Size = new System.Drawing.Size(79, 65);
            this.btn_RunBack.TabIndex = 5;
            this.btn_RunBack.Text = "<<";
            this.btn_RunBack.UseVisualStyleBackColor = false;
            this.btn_RunBack.Click += new System.EventHandler(this.btn_RunBack_Click);
            // 
            // btn_CreateBoard
            // 
            this.btn_CreateBoard.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btn_CreateBoard.Location = new System.Drawing.Point(953, 12);
            this.btn_CreateBoard.Name = "btn_CreateBoard";
            this.btn_CreateBoard.Size = new System.Drawing.Size(161, 65);
            this.btn_CreateBoard.TabIndex = 6;
            this.btn_CreateBoard.Text = "צור לוח";
            this.btn_CreateBoard.UseVisualStyleBackColor = true;
            this.btn_CreateBoard.Click += new System.EventHandler(this.btn_CreateBoard_Click);
            // 
            // txtbox_NumDiscs
            // 
            this.txtbox_NumDiscs.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.txtbox_NumDiscs.Location = new System.Drawing.Point(697, 6);
            this.txtbox_NumDiscs.Multiline = true;
            this.txtbox_NumDiscs.Name = "txtbox_NumDiscs";
            this.txtbox_NumDiscs.Size = new System.Drawing.Size(159, 26);
            this.txtbox_NumDiscs.TabIndex = 7;
            this.txtbox_NumDiscs.Text = "3";
            this.txtbox_NumDiscs.TextChanged += new System.EventHandler(this.txtbox_NumDiscs_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label1.Location = new System.Drawing.Point(861, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 17);
            this.label1.TabIndex = 8;
            this.label1.Text = ":כמות דיסקיות";
            // 
            // lbl_Range
            // 
            this.lbl_Range.AutoSize = true;
            this.lbl_Range.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.lbl_Range.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbl_Range.Location = new System.Drawing.Point(632, 9);
            this.lbl_Range.Name = "lbl_Range";
            this.lbl_Range.Size = new System.Drawing.Size(64, 17);
            this.lbl_Range.TabIndex = 9;
            this.lbl_Range.Text = "בין 2 ל13";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel1.Location = new System.Drawing.Point(12, 83);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1102, 453);
            this.panel1.TabIndex = 10;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // trkbar_Speed
            // 
            this.trkbar_Speed.Location = new System.Drawing.Point(658, 35);
            this.trkbar_Speed.Maximum = 500;
            this.trkbar_Speed.Minimum = 5;
            this.trkbar_Speed.Name = "trkbar_Speed";
            this.trkbar_Speed.Size = new System.Drawing.Size(242, 45);
            this.trkbar_Speed.TabIndex = 11;
            this.trkbar_Speed.TickFrequency = 20;
            this.trkbar_Speed.Value = 200;
            this.trkbar_Speed.Scroll += new System.EventHandler(this.trkbar_Speed_Scroll);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label2.Location = new System.Drawing.Point(906, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 17);
            this.label2.TabIndex = 12;
            this.label2.Text = "איטי";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label3.Location = new System.Drawing.Point(632, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 17);
            this.label3.TabIndex = 13;
            this.label3.Text = "מהיר";
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1126, 548);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.trkbar_Speed);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lbl_Range);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtbox_NumDiscs);
            this.Controls.Add(this.btn_CreateBoard);
            this.Controls.Add(this.btn_RunBack);
            this.Controls.Add(this.btn_BackToStart);
            this.Controls.Add(this.btn_StepBack);
            this.Controls.Add(this.btn_Run);
            this.Controls.Add(this.btn_Next);
            this.Controls.Add(this.btn_StopRun);
            this.Name = "Form1";
            this.Text = "מגדלי האנוי";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.trkbar_Speed)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_StopRun;
        private System.Windows.Forms.Button btn_Next;
        private System.Windows.Forms.Button btn_Run;
        private System.Windows.Forms.Button btn_StepBack;
        private System.Windows.Forms.Button btn_BackToStart;
        private System.Windows.Forms.Button btn_RunBack;
        private System.Windows.Forms.Button btn_CreateBoard;
        private System.Windows.Forms.TextBox txtbox_NumDiscs;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_Range;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TrackBar trkbar_Speed;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Timer timer2;
    }
}


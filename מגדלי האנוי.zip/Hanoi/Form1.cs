﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hanoi
{
    public partial class Form1 : Form
    {
        int discH, discW, numinstructions, instructionP, h, w;
        int[] boardP;  
        int[,] board;
        byte[,] instructions;
        int numDiscsTemp = 3, numDiscs = 3;
        Graphics g;
        Brush brush;
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            boardP = new int[3];
            trkbar_Speed.Enabled = false;
            g = panel1.CreateGraphics();
            h = panel1.Height / 12;
            w = panel1.Width / 11;
        }
        private void btn_CreateBoard_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            timer2.Enabled = false;
            numDiscs = numDiscsTemp;
            discH = (panel1.Height - 2 * h) / numDiscs;
            discW = w / numDiscs;
            trkbar_Speed.Enabled = true;
            board = new int[3, numDiscs];
            boardP = new int[3];
            boardP[0] = 0;
            boardP[1] = 0;
            boardP[2] = 0;
            numinstructions = (int)(Math.Pow(2, numDiscs) - 1);
            instructions = new byte[numinstructions, 2];
            instructionP = 0;
            for (int i = numDiscs; i > 0; i--)
            {
                board[0, boardP[0]] = i;
                boardP[0]++;
            }
            SolveHanoi(0, 1, 2, numDiscs);
            instructionP = 0;
            btn_BackToStart.Enabled = false;
            btn_RunBack.Enabled = false;
            btn_StepBack.Enabled = false;
            btn_StopRun.Enabled = false;
            btn_Next.Enabled = true;
            btn_Run.Enabled = true;
            DrawBoard();
        }
        private void btn_Run_Click(object sender, EventArgs e)
        {
            timer2.Enabled = false;
            timer1.Enabled = true;
            btn_BackToStart.Enabled = true;
            btn_Next.Enabled = true;
            btn_RunBack.Enabled = true;
            btn_StepBack.Enabled = true;
            btn_StopRun.Enabled = true;
            btn_Run.Enabled = false;
        }
        private void btn_Next_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            timer2.Enabled = false;
            btn_StopRun.Enabled = false;
            if (nextStep() == false)
            {
                btn_Next.Enabled = false;
                btn_Run.Enabled = false;
            }
            else
            {
                btn_BackToStart.Enabled = true;
                btn_RunBack.Enabled = true;
                btn_StepBack.Enabled = true;
            }
        }
        private void btn_StopRun_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            timer2.Enabled = false;
            btn_StopRun.Enabled = false;
            btn_BackToStart.Enabled = true;
            btn_RunBack.Enabled = true;
            btn_StepBack.Enabled = true;
            
        }
        private void btn_StepBack_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            timer2.Enabled = false;
            btn_StopRun.Enabled = false;
            btn_Next.Enabled = true;
            btn_Run.Enabled = true;
            if (stepBack() == false)
            {
                btn_BackToStart.Enabled = false;
                btn_RunBack.Enabled = false;
                btn_StepBack.Enabled = false;
            }
            else
            {
                btn_Next.Enabled = true;
                btn_Run.Enabled = true;
            }
        }
        private void btn_RunBack_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            timer2.Enabled = true;
            btn_BackToStart.Enabled = true;
            btn_Next.Enabled = true;
            btn_Run.Enabled = true;
            btn_StepBack.Enabled = true;
            btn_StopRun.Enabled = true;
            btn_RunBack.Enabled = false;
        }
        private void btn_BackToStart_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            timer2.Enabled = false;
            btn_BackToStart.Enabled = false;
            btn_RunBack.Enabled = false;
            btn_StopRun.Enabled = false;
            btn_StepBack.Enabled = false;
            btn_Run.Enabled = false;
            btn_Next.Enabled = false;
            while (stepBack() == true) ;
            btn_Run.Enabled = true;
            btn_Next.Enabled = true;
        }
        private void SolveHanoi(byte a, byte b, byte c, int numOfDiscs)
        {
            if (numOfDiscs == 1)
                newInstruction(a, c);
            else
            {
                SolveHanoi(a, c, b, numOfDiscs - 1);
                newInstruction(a, c);
                SolveHanoi(b, a, c, numOfDiscs - 1);
            }
        }
        private void newInstruction(byte from, byte to)
        {
            instructions[instructionP, 0] = from;
            instructions[instructionP, 1] = to;
            instructionP++;
        }
        private void trkbar_Speed_Scroll(object sender, EventArgs e)
        {
            timer1.Interval = trkbar_Speed.Value;
            timer2.Interval = trkbar_Speed.Value;
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (nextStep() == false)
            {
                btn_Next.Enabled = false;
                btn_Run.Enabled = false;
                btn_StopRun.Enabled = false;
                timer1.Enabled = false;
            }
        }
        private void timer2_Tick(object sender, EventArgs e)
        {
            if (stepBack() == false)
            {
                btn_BackToStart.Enabled = false;
                btn_RunBack.Enabled = false;
                btn_StopRun.Enabled = false;
                btn_StepBack.Enabled = false;
                timer2.Enabled = false;
            }
        }
        private bool stepBack()
        {
            instructionP--;
            board[instructions[instructionP, 0], boardP[instructions[instructionP, 0]]++] = board[instructions[instructionP, 1], --boardP[instructions[instructionP, 1]]]; //move higest disc of src into top of dest 
            board[instructions[instructionP, 1], boardP[instructions[instructionP, 1]]] = 0;
            DrawBoard();
            if (instructionP == 0)
                return false;
            else
                return true;
        }
        private bool nextStep()
        {
            board[instructions[instructionP, 1], boardP[instructions[instructionP, 1]]++] = board[instructions[instructionP, 0], --boardP[instructions[instructionP, 0]]]; //move higest disc of src into top of dest 
            board[instructions[instructionP, 0], boardP[instructions[instructionP, 0]]] = 0;
            DrawBoard();
            instructionP++;
            if (instructionP == numinstructions)
                return false;
            else
                return true;
        }
        private void txtbox_NumDiscs_TextChanged(object sender, EventArgs e)
        {
            try 
            {
                numDiscsTemp = int.Parse(txtbox_NumDiscs.Text);
                if (numDiscsTemp < 1 || numDiscsTemp > 13)
                {
                    numDiscsTemp = numDiscs;
                    txtbox_NumDiscs.BackColor = Color.Red;
                }
                else
                {
                    txtbox_NumDiscs.BackColor = SystemColors.Window;
                }
            }
            catch {}
        }
        private void DrawBoard()
        {
            panel1.Enabled = false;
            panel1.Controls.Clear();
            panel1.Enabled = true;
            brush = new SolidBrush(Color.DarkTurquoise);
            g.FillRectangle(brush, w, panel1.Height - h , w * 9, h);
            g.FillRectangle(brush, w * 2 + 10, h, w - 20, panel1.Height - h * 2);
            g.FillRectangle(brush, w * 5 + 10, h, w - 20, panel1.Height - h * 2);
            g.FillRectangle(brush, w * 8 + 10, h, w - 20, panel1.Height - h * 2);
            for (int i = 0; i < 3; i++)
            {
                for(int j = 0; j < numDiscs && board[i, j] > 0; j++)
                {
                    brush = new SolidBrush(Color.FromArgb(255 - board[i, j] * (255 / numDiscs), (board[i, j] * 2 * (255 / numDiscs)) % 256, (board[i, j] * 4 * (255 / numDiscs)) % 256));
                    g.FillRectangle(brush, 2 * w + (w * 3 * i) - (board[i, j] * discW), panel1.Height - h - discH * (j + 1), w + 2 * (board[i, j] * discW), discH);
                }
            }
        }
    }
}

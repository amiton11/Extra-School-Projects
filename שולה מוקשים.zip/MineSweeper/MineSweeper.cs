﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MineSweeper
{
    public partial class Form1 : Form
    {
        int XSize, YSize, MineAmount, currentPercent, counter, numFlags, sec, min, h, w;
        public Button[,] btnArr;
        byte[,] btnArrInfo;
        bool[,] flags;
        bool firstClick;
        Random rand;
        Image flag;
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            chkbox_16x16.Checked = true;
            chkbox_Normal.Checked = true;
            rand = new Random();
            flag = MineSweeper.Properties.Resources.flag;
        }
        private void chkbox_8x8_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_8x8.Checked == true)
            {
                chkbox_8x8.Enabled = false;
                chkbox_16x16.Checked = false;
                chkbox_16x16.Enabled = true;
                chkbox_24x24.Checked = false;
                chkbox_24x24.Enabled = true;
                chkbox_32x32.Checked = false;
                chkbox_32x32.Enabled = true;
                chkbox_CustomSize.Checked = false;
                chkbox_CustomSize.Enabled = true;
                txtbox_XSize.Enabled = false;
                txtbox_YSize.Enabled = false;
                txtbox_XSize.BackColor = SystemColors.Window;
                txtbox_YSize.BackColor = SystemColors.Window;
                XSize = 8;
                YSize = 8;
                UpdateChkBoxInfo();
            }
        }
        private void chkbox_16x16_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_16x16.Checked == true)
            {
                chkbox_16x16.Enabled = false;
                chkbox_8x8.Checked = false;
                chkbox_8x8.Enabled = true;
                chkbox_24x24.Checked = false;
                chkbox_24x24.Enabled = true;
                chkbox_32x32.Checked = false;
                chkbox_32x32.Enabled = true;
                chkbox_CustomSize.Checked = false;
                chkbox_CustomSize.Enabled = true;
                txtbox_XSize.Enabled = false;
                txtbox_YSize.Enabled = false;
                txtbox_XSize.BackColor = SystemColors.Window;
                txtbox_YSize.BackColor = SystemColors.Window;
                XSize = 16;
                YSize = 16;
                UpdateChkBoxInfo();
            }
        }
        private void chkbox_24x24_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_24x24.Checked == true)
            {
                chkbox_24x24.Enabled = false;
                chkbox_16x16.Checked = false;
                chkbox_16x16.Enabled = true;
                chkbox_8x8.Checked = false;
                chkbox_8x8.Enabled = true;
                chkbox_32x32.Checked = false;
                chkbox_32x32.Enabled = true;
                chkbox_CustomSize.Checked = false;
                chkbox_CustomSize.Enabled = true;
                txtbox_XSize.Enabled = false;
                txtbox_YSize.Enabled = false;
                txtbox_XSize.BackColor = SystemColors.Window;
                txtbox_YSize.BackColor = SystemColors.Window;
                XSize = 24;
                YSize = 24;
                UpdateChkBoxInfo();
            }
        }
        private void chkbox_32x32_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_32x32.Checked == true)
            {
                chkbox_32x32.Enabled = false;
                chkbox_16x16.Checked = false;
                chkbox_16x16.Enabled = true;
                chkbox_24x24.Checked = false;
                chkbox_24x24.Enabled = true;
                chkbox_8x8.Checked = false;
                chkbox_8x8.Enabled = true;
                chkbox_CustomSize.Checked = false;
                chkbox_CustomSize.Enabled = true;
                txtbox_XSize.Enabled = false;
                txtbox_YSize.Enabled = false;
                txtbox_XSize.BackColor = SystemColors.Window;
                txtbox_YSize.BackColor = SystemColors.Window;
                XSize = 32;
                YSize = 32;
                UpdateChkBoxInfo();
            }
        }
        private void chkbox_CustomSize_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_CustomSize.Checked == true)
            {
                chkbox_8x8.Checked = false;
                chkbox_8x8.Enabled = true;
                chkbox_16x16.Checked = false;
                chkbox_16x16.Enabled = true;
                chkbox_24x24.Checked = false;
                chkbox_24x24.Enabled = true;
                chkbox_32x32.Checked = false;
                chkbox_32x32.Enabled = true;
                chkbox_CustomSize.Enabled = false;
                txtbox_XSize.Enabled = true;
                txtbox_YSize.Enabled = true;
                txtbox_XSize_TextChanged(this, null);
                txtbox_YSize_TextChanged(this, null);
            }
        }
        private void chkbox_Easy_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_Easy.Checked == true)
            {
                chkbox_Easy.Enabled = false;
                chkbox_Normal.Checked = false;
                chkbox_Normal.Enabled = true;
                chkbox_Hard.Checked = false;
                chkbox_Hard.Enabled = true;
                chkbox_CustomAmount.Checked = false;
                chkbox_CustomAmount.Enabled = true;
                txtbox_MineAmount.Enabled = false;
                currentPercent = 8;
            }
        }
        private void chkbox_Normal_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_Normal.Checked == true)
            {
                chkbox_Normal.Enabled = false;
                chkbox_Easy.Checked = false;
                chkbox_Easy.Enabled = true;
                chkbox_Hard.Checked = false;
                chkbox_Hard.Enabled = true;
                chkbox_CustomAmount.Checked = false;
                chkbox_CustomAmount.Enabled = true;
                txtbox_MineAmount.Enabled = false;
                currentPercent = 12;
            }
        }
        private void chkbox_Hard_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_Hard.Checked == true)
            {
                chkbox_Hard.Enabled = false;
                chkbox_Easy.Checked = false;
                chkbox_Easy.Enabled = true;
                chkbox_Normal.Checked = false;
                chkbox_Normal.Enabled = true;
                chkbox_CustomAmount.Checked = false;
                chkbox_CustomAmount.Enabled = true;
                txtbox_MineAmount.Enabled = false;
                currentPercent = 16;
            }
        }
        private void chkbox_CustomAmount_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_CustomAmount.Checked == true)
            {
                chkbox_CustomAmount.Enabled = false;
                chkbox_Normal.Checked = false;
                chkbox_Normal.Enabled = true;
                chkbox_Hard.Checked = false;
                chkbox_Hard.Enabled = true;
                chkbox_Easy.Checked = false;
                chkbox_Easy.Enabled = true;
                txtbox_MineAmount.Enabled = true;
                MineAmount = 1;
                try
                {
                    txtbox_MineAmount.BackColor = SystemColors.Window;
                    MineAmount = int.Parse(txtbox_MineAmount.Text);
                }
                catch
                {
                    txtbox_MineAmount.BackColor = Color.Red;
                }
                if (MineAmount < 1)
                {
                    MineAmount = 1;
                    txtbox_MineAmount.BackColor = Color.Red;
                }
            }
        }
        private void txtbox_XSize_TextChanged(object sender, EventArgs e)
        {
            XSize = 2;
            YSize = 2;
            try
            {
                txtbox_XSize.BackColor = SystemColors.Window;
                XSize = int.Parse(txtbox_XSize.Text);
                try
                {
                    YSize = int.Parse(txtbox_YSize.Text);
                    UpdateChkBoxInfo();
                }
                catch
                {
                    chkbox_Easy.Text = "קל";
                    chkbox_Normal.Text = "בינוני";
                    chkbox_Hard.Text = "קשה";
                    chkbox_CustomAmount.Text = "כמות שונה";
                }
            }
            catch
            {
                txtbox_XSize.BackColor = Color.Red;
                chkbox_Easy.Text = "קל";
                chkbox_Normal.Text = "בינוני";
                chkbox_Hard.Text = "קשה";
                chkbox_CustomAmount.Text = "כמות שונה";
            }
            if (XSize < 2 || XSize > 60) //more then 60 and the buttons become too small
            {
                txtbox_XSize.BackColor = Color.Red;
                chkbox_Easy.Text = "קל";
                chkbox_Normal.Text = "בינוני";
                chkbox_Hard.Text = "קשה";
                chkbox_CustomAmount.Text = "כמות שונה";
            }
        }
        private void txtbox_YSize_TextChanged(object sender, EventArgs e)
        {
            try
            {
                txtbox_YSize.BackColor = SystemColors.Window;
                YSize = int.Parse(txtbox_YSize.Text);
                try
                {
                    XSize = int.Parse(txtbox_XSize.Text);
                    UpdateChkBoxInfo();
                }
                catch
                {
                    chkbox_Easy.Text = "קל";
                    chkbox_Normal.Text = "בינוני";
                    chkbox_Hard.Text = "קשה";
                    chkbox_CustomAmount.Text = "כמות שונה";
                }
            }
            catch
            {
                txtbox_YSize.BackColor = Color.Red;
                chkbox_Easy.Text = "קל";
                chkbox_Normal.Text = "בינוני";
                chkbox_Hard.Text = "קשה";
                chkbox_CustomAmount.Text = "כמות שונה";
            }
            if (YSize < 2 || YSize > 60)//more then 60 and the buttons become too small
            {
                txtbox_YSize.BackColor = Color.Red;
                chkbox_Easy.Text = "קל";
                chkbox_Normal.Text = "בינוני";
                chkbox_Hard.Text = "קשה";
                chkbox_CustomAmount.Text = "כמות שונה";
            }
        }
        private void UpdateChkBoxInfo()
        {
            if ((int)((double)(XSize * YSize) / 25 * 2) <= 1)
                chkbox_Easy.Text = "קל(8% מוקשים -  מוקש אחד)";
            else
                chkbox_Easy.Text = "קל(8% מוקשים - " + ((int)((double)(XSize * YSize) / 25 * 2)).ToString() + " מוקשים)";
            if ((int)((double)(XSize * YSize) / 25 * 3) <= 1)
                chkbox_Normal.Text = "בינוני(12% מוקשים - מוקש אחד)";
            else
                chkbox_Normal.Text = "בינוני(12% מוקשים - " + ((int)((double)(XSize * YSize) / 25 * 3)).ToString() + " מוקשים)";
            if ((int)((double)(XSize * YSize) / 25 * 4) <= 1)
                chkbox_Hard.Text = "קשה(16% מוקשים - מוקש אחד)";
            else
                chkbox_Hard.Text = "קשה(16% מוקשים - " + ((int)((double)(XSize * YSize) / 25 * 4)).ToString() + " מוקשים)";
            chkbox_CustomAmount.Text = "כמות שונה(בין 1 ל" + (XSize * YSize - 1).ToString() + ")";
        }
        private void txtbox_MineAmount_TextChanged(object sender, EventArgs e)
        {
            MineAmount = 1;
            try
            {
                txtbox_MineAmount.BackColor = SystemColors.Window;
                MineAmount = int.Parse(txtbox_MineAmount.Text);
            }
            catch
            {
                txtbox_MineAmount.BackColor = Color.Red;
            }
            if (MineAmount < 1)
            {
                MineAmount = 1;
                txtbox_MineAmount.BackColor = Color.Red;
            }
        }
        private void btn_StartGame_Click(object sender, EventArgs e)
        {
            h = panel1.Height / YSize;
            w = panel1.Width / XSize;
            if (chkbox_CustomAmount.Checked == false)
            {
                MineAmount = (int)((double)(XSize * YSize) / 100 * currentPercent);
                if (MineAmount < 1)
                    MineAmount = 1;
            }
            counter = (XSize * YSize) - MineAmount;
            numFlags = MineAmount;
            txtbox_Flags.Text = numFlags.ToString();
            firstClick = true;
            panel1.Enabled = true;
            panel1.Controls.Clear();
            timer1.Enabled = false;
            txtbox_Minutes.Text = "";
            txtbox_Seconds.Text = "";
            btnArr = new Button[YSize, XSize];
            flags = new bool[YSize, XSize];
            for (int i = 0; i < YSize; i++)
            {
                for (int j = 0; j < XSize; j++)
                {
                    btnArr[i, j] = new Button();
                    btnArr[i, j].Height = h;
                    btnArr[i, j].Width = w;
                    if (h < w)
                        btnArr[i, j].Font = new Font(btnArr[i, j].Font.FontFamily, (int)(h / 2.3 - 1));
                    else
                        btnArr[i, j].Font = new Font(btnArr[i, j].Font.FontFamily, (int)(w / 2.3 - 1));
                    btnArr[i, j].Top = h * i;
                    btnArr[i, j].Left = w * j;
                    btnArr[i, j].BackColor = Color.FromArgb(255, 120, 180, 180);
                    panel1.Controls.Add(btnArr[i, j]);
                    btnArr[i, j].MouseDown += new System.Windows.Forms.MouseEventHandler(ButtonArrayMouseClick);
                    btnArr[i, j].ForeColor = Color.FromArgb(255, 120, 180, 180);
                    btnArr[i, j].Text = (i * 1000 + j*10).ToString();
                    flags[i, j] = false;
                }
            }
        }
        private byte[,] GenerateBasicBoardInfo(int XPoint, int YPoint, int mines)
        {
            byte[,] Arr = new byte[YSize, XSize];
            int freeSpace = (XSize * YSize) - 1;
            for (int i = 0; i < YSize; i++)
            {
                for (int j = 0; j < XSize; j++)
                {
                    Arr[i, j] = 0; // 0 means it is empty
                }
            }
            for (int i = 0; i < YSize; i++)
            {
                for (int j = 0; j < XSize; j++)
                {
                    if (i != YPoint || j != XPoint)
                    {
                        if (rand.Next(freeSpace) < mines)
                        {
                            mines--;
                            Arr[i, j] = 9; // 9 means thare is a mine there
                            if (j > 0 && j < XSize - 1)
                            {
                                Arr[i, j + 1]++;
                                Arr[i, j - 1]++;
                                if (i > 0)
                                {
                                    Arr[i - 1, j - 1]++;
                                    Arr[i - 1, j]++;
                                    Arr[i - 1, j + 1]++;
                                }
                                if (i < YSize - 1)
                                {
                                    Arr[i + 1, j - 1]++;
                                    Arr[i + 1, j]++;
                                    Arr[i + 1, j + 1]++;
                                }
                            }
                            else if (j == 0)
                            {
                                Arr[i, j + 1]++;
                                if (i > 0)
                                {
                                    Arr[i - 1, j]++;
                                    Arr[i - 1, j + 1]++;
                                }
                                if (i < YSize - 1)
                                {
                                    Arr[i + 1, j]++;
                                    Arr[i + 1, j + 1]++;
                                }
                            }
                            else if (j == XSize - 1)
                            {
                                Arr[i, j - 1]++;
                                if (i > 0)
                                {
                                    Arr[i - 1, j]++;
                                    Arr[i - 1, j - 1]++;
                                }
                                if (i < YSize - 1)
                                {
                                    Arr[i + 1, j]++;
                                    Arr[i + 1, j - 1]++;
                                }
                            }
                        }
                        freeSpace--;
                    }
                }
            }
            for (int i = 0; i < YSize; i++)
            {
                for (int j = 0; j < XSize; j++)
                {
                    if (Arr[i, j] > 9)
                        Arr[i, j] = 9;
                }
            }
            return (Arr);
        }
        private void ButtonArrayMouseClick(object sender, MouseEventArgs e)
        {
            string s = ((Button)(sender)).Text;
            if (firstClick == true && e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                btnArrInfo = GenerateBasicBoardInfo((int.Parse(s) % 1000) / 10, int.Parse(s) / 1000, MineAmount);
                reveal((int.Parse(s) % 1000) / 10, int.Parse(s) / 1000);
                sec = 0;
                min = 0;
                txtbox_Minutes.Text = "00";
                txtbox_Seconds.Text = "00";
                timer1.Enabled = true;
                firstClick = false;
            }
            else
            {
                try
                {
                    if (((Button)(sender)).BackColor == Color.FromArgb(255, 120, 180, 180))
                    {
                        int x = (int.Parse(s) % 1000) / 10, y = int.Parse(s) / 1000;
                        if (e.Button == System.Windows.Forms.MouseButtons.Left)
                        {
                            if (flags[y, x] == false)
                            {
                                if (btnArrInfo[y, x] < 9)
                                    reveal(x, y);
                                else if (btnArrInfo[y, x] == 9)
                                    mineClick(x, y);
                            }
                        }
                        else if (e.Button == System.Windows.Forms.MouseButtons.Right)
                        {
                            if (btnArrInfo[y, x] < 10)
                                btnArrRightClick(x, y);
                        }
                    }
                }
                catch { }
            }
        }
        private void btnArrRightClick(int x, int y)
        {
            if (flags[y, x] == false && btnArrInfo[y,x] != 10)
            {
                if (h >= w)
                    btnArr[y, x].Image = new Bitmap(flag, new Size(w - 4, w - 4));
                else
                    btnArr[y, x].Image = new Bitmap(flag, new Size(h - 4, h - 4));
                btnArr[y, x].Font = new Font(btnArr[y, x].Font.FontFamily,(float)(0.1));
                btnArr[y, x].TextAlign = ContentAlignment.TopLeft;
                flags[y, x] = true;
                numFlags--;
                txtbox_Flags.Text = numFlags.ToString();
            }
            else if (flags[y, x] == true)
            {
                if (h < w)
                    btnArr[y, x].Font = new Font(btnArr[y, x].Font.FontFamily, (int)(h / 2.5));
                else
                    btnArr[y, x].Font = new Font(btnArr[y, x].Font.FontFamily, (int)(w / 2.5));
                btnArr[y, x].Image = null;
                flags[y, x] = false;
                numFlags++;
                txtbox_Flags.Text = numFlags.ToString();
            }
            if (numFlags == 0 && btnArrInfo[y,x] != 10)
            {
                for (int i = 0; i < YSize; i++)
                {
                    for (int j = 0; j < XSize; j++)
                    {
                        if (flags[i, j] == true && btnArrInfo[i, j] != 9)
                        {
                            i = YSize;
                            break;
                        }
                        else if (i == YSize - 1 && j == XSize - 1)
                        {
                            win();
                        }
                    }
                    
                }
            }
        }
        private void mineClick(int x, int y)
        {
            btnArr[y, x].Text = "*";
            btnArr[y, x].BackColor = Color.Black;
            btnArr[y, x].ForeColor = Color.Red;
            timer1.Enabled = false;
            MessageBox.Show("Game Over");
            for (int i = 0; i < YSize; i++)
            {
                for (int j = 0; j < XSize; j++)
                {
                    if (btnArrInfo[i, j] < 10)
                    {
                        btnArr[i, j].ForeColor = Color.Black;
                        btnArr[i, j].Text = (btnArrInfo[i, j]).ToString();
                        switch (btnArrInfo[i, j])
                        {
                            case 0:
                                btnArr[i, j].BackColor = Color.WhiteSmoke;
                                break;
                            case 1:
                                btnArr[i, j].BackColor = Color.Cyan;
                                break;
                            case 2:
                                btnArr[i, j].BackColor = Color.Yellow;
                                break;
                            case 3:
                                btnArr[i, j].BackColor = Color.Green;
                                break;
                            case 4:
                                btnArr[i, j].BackColor = Color.Pink;
                                break;
                            case 5:
                                btnArr[i, j].BackColor = Color.Blue;
                                break;
                            case 6:
                                btnArr[i, j].BackColor = Color.Red;
                                break;
                            case 7:
                                btnArr[i, j].BackColor = Color.Purple;
                                break;
                            case 8:
                                btnArr[i, j].BackColor = Color.Brown;
                                break;
                            case 9:
                                if (btnArr[i, j].Image == null)
                                {
                                    btnArr[i, j].Text = "*";
                                    btnArr[i, j].BackColor = Color.Black;
                                    btnArr[i, j].ForeColor = Color.Red;
                                }
                                else
                                {
                                    btnArr[i, j].Text = "";
                                }
                                break;
                        }
                    }
                }
            }
            panel1.Enabled = false;
            txtbox_Flags.Text = "";
            txtbox_Minutes.Text = "";
            txtbox_Seconds.Text = "";
        }
        private void reveal(int x, int y)
        {
            if (btnArrInfo[y, x] == 0)
            {
                counter--;
                btnArr[y, x].Text = "0";
                btnArrInfo[y, x] = 10;
                btnArr[y, x].BackColor = Color.WhiteSmoke;
                btnArr[y, x].ForeColor = Color.Black;
                if (x > 0 && x < XSize - 1)
                {
                    reveal(x - 1, y);
                    reveal(x + 1, y);
                    if (y > 0)
                    {
                        reveal(x - 1, y - 1);
                        reveal(x, y - 1);
                        reveal(x + 1, y - 1);
                    }
                    if (y < YSize - 1)
                    {
                        reveal(x - 1, y + 1);
                        reveal(x, y + 1);
                        reveal(x + 1, y + 1);
                    }
                }
                else if (x == 0)
                {
                    reveal(x + 1, y);
                    if (y > 0)
                    {
                        reveal(x, y - 1);
                        reveal(x + 1, y - 1);
                    }
                    if (y < YSize - 1)
                    {
                        reveal(x, y + 1);
                        reveal(x + 1, y + 1);
                    }
                }
                else if (x == XSize - 1)
                {
                    reveal(x - 1, y);
                    if (y > 0)
                    {
                        reveal(x, y - 1);
                        reveal(x - 1, y - 1);
                    }
                    if (y < YSize - 1)
                    {
                        reveal(x, y + 1);
                        reveal(x - 1, y + 1);
                    }
                }
            }
            else if (btnArrInfo[y, x] < 9)
            {
                counter--;
                btnArr[y, x].ForeColor = Color.Black;
                btnArr[y, x].Text = (btnArrInfo[y, x]).ToString();
                switch (btnArrInfo[y, x])
                {
                    case 1:
                        btnArr[y, x].BackColor = Color.Cyan;
                        break;
                    case 2:
                        btnArr[y, x].BackColor = Color.Yellow;
                        break;
                    case 3:
                        btnArr[y, x].BackColor = Color.Green;
                        break;
                    case 4:
                        btnArr[y, x].BackColor = Color.Pink;
                        break;
                    case 5:
                        btnArr[y, x].BackColor = Color.Blue;
                        break;
                    case 6:
                        btnArr[y, x].BackColor = Color.Red;
                        break;
                    case 7:
                        btnArr[y, x].BackColor = Color.Purple;
                        break;
                    case 8:
                        btnArr[y, x].BackColor = Color.Brown;
                        break;
                }
                btnArrInfo[y, x] = 10;
            }
            if (counter == 0)
            {
                win();
                counter = 1;
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (sec == 59)
            {
                sec = 0;
                min++;
                txtbox_Seconds.Text = "00";
                if (min < 10)
                    txtbox_Minutes.Text = "0" + (min).ToString();
                else
                    txtbox_Minutes.Text = (min).ToString();
            }
            else
            {
                sec++;
                if (sec < 10)
                    txtbox_Seconds.Text = "0" + (sec).ToString();
                else
                    txtbox_Seconds.Text = (sec).ToString();
                if (min < 10)
                    txtbox_Minutes.Text = "0" + (min).ToString();
                else
                    txtbox_Minutes.Text = (min).ToString();
            }
        }
        private void win()
        {
            for (int i = 0; i < YSize; i++)
            {
                for (int j = 0; j < XSize; j++)
                {
                    if (btnArr[i, j].Image == null)
                    {
                        if (btnArrInfo[i, j] == 9)
                        {
                            btnArr[i, j].Text = "*";
                            btnArr[i, j].BackColor = Color.Black;
                            btnArr[i, j].ForeColor = Color.Red;
                        }
                        else if (btnArr[i, j].BackColor == Color.FromArgb(255, 120, 180, 180))
                        {
                            btnArr[i, j].Text = "";
                        }
                    }
                    else
                    {
                        btnArr[i, j].Text = "";
                    }
                }
            }
            timer1.Enabled = false;
            MessageBox.Show("You won! it took you " + (min).ToString() + "minutes, and " + (sec).ToString() + " seconds");
            panel1.Enabled = false;
            txtbox_Flags.Text = "";
            txtbox_Minutes.Text = "";
            txtbox_Seconds.Text = "";
        }
    }
}
 
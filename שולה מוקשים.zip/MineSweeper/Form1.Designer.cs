﻿namespace MineSweeper
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btn_StartGame = new System.Windows.Forms.Button();
            this.chkbox_8x8 = new System.Windows.Forms.CheckBox();
            this.chkbox_16x16 = new System.Windows.Forms.CheckBox();
            this.chkbox_24x24 = new System.Windows.Forms.CheckBox();
            this.chkbox_CustomSize = new System.Windows.Forms.CheckBox();
            this.txtbox_XSize = new System.Windows.Forms.TextBox();
            this.txtbox_YSize = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.chkbox_32x32 = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.chkbox_Easy = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.chkbox_Normal = new System.Windows.Forms.CheckBox();
            this.chkbox_Hard = new System.Windows.Forms.CheckBox();
            this.chkbox_CustomAmount = new System.Windows.Forms.CheckBox();
            this.txtbox_MineAmount = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.txtbox_Seconds = new System.Windows.Forms.TextBox();
            this.txtbox_Minutes = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtbox_Flags = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // btn_StartGame
            // 
            this.btn_StartGame.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btn_StartGame.Location = new System.Drawing.Point(1038, 2);
            this.btn_StartGame.Name = "btn_StartGame";
            this.btn_StartGame.Size = new System.Drawing.Size(157, 85);
            this.btn_StartGame.TabIndex = 0;
            this.btn_StartGame.Text = "התחל משחק";
            this.btn_StartGame.UseVisualStyleBackColor = true;
            this.btn_StartGame.Click += new System.EventHandler(this.btn_StartGame_Click);
            // 
            // chkbox_8x8
            // 
            this.chkbox_8x8.AutoSize = true;
            this.chkbox_8x8.Location = new System.Drawing.Point(1091, 124);
            this.chkbox_8x8.Name = "chkbox_8x8";
            this.chkbox_8x8.Size = new System.Drawing.Size(43, 17);
            this.chkbox_8x8.TabIndex = 1;
            this.chkbox_8x8.Text = "8x8";
            this.chkbox_8x8.UseVisualStyleBackColor = true;
            this.chkbox_8x8.CheckedChanged += new System.EventHandler(this.chkbox_8x8_CheckedChanged);
            // 
            // chkbox_16x16
            // 
            this.chkbox_16x16.AutoSize = true;
            this.chkbox_16x16.Location = new System.Drawing.Point(1091, 147);
            this.chkbox_16x16.Name = "chkbox_16x16";
            this.chkbox_16x16.Size = new System.Drawing.Size(55, 17);
            this.chkbox_16x16.TabIndex = 2;
            this.chkbox_16x16.Text = "16x16";
            this.chkbox_16x16.UseVisualStyleBackColor = true;
            this.chkbox_16x16.CheckedChanged += new System.EventHandler(this.chkbox_16x16_CheckedChanged);
            // 
            // chkbox_24x24
            // 
            this.chkbox_24x24.AutoSize = true;
            this.chkbox_24x24.Location = new System.Drawing.Point(1091, 170);
            this.chkbox_24x24.Name = "chkbox_24x24";
            this.chkbox_24x24.Size = new System.Drawing.Size(55, 17);
            this.chkbox_24x24.TabIndex = 3;
            this.chkbox_24x24.Text = "24x24";
            this.chkbox_24x24.UseVisualStyleBackColor = true;
            this.chkbox_24x24.CheckedChanged += new System.EventHandler(this.chkbox_24x24_CheckedChanged);
            // 
            // chkbox_CustomSize
            // 
            this.chkbox_CustomSize.AutoSize = true;
            this.chkbox_CustomSize.Location = new System.Drawing.Point(1091, 216);
            this.chkbox_CustomSize.Name = "chkbox_CustomSize";
            this.chkbox_CustomSize.Size = new System.Drawing.Size(84, 17);
            this.chkbox_CustomSize.TabIndex = 4;
            this.chkbox_CustomSize.Text = "גודל משלך";
            this.chkbox_CustomSize.UseVisualStyleBackColor = true;
            this.chkbox_CustomSize.CheckedChanged += new System.EventHandler(this.chkbox_CustomSize_CheckedChanged);
            // 
            // txtbox_XSize
            // 
            this.txtbox_XSize.Location = new System.Drawing.Point(1067, 239);
            this.txtbox_XSize.Name = "txtbox_XSize";
            this.txtbox_XSize.Size = new System.Drawing.Size(43, 20);
            this.txtbox_XSize.TabIndex = 5;
            this.txtbox_XSize.TextChanged += new System.EventHandler(this.txtbox_XSize_TextChanged);
            // 
            // txtbox_YSize
            // 
            this.txtbox_YSize.Location = new System.Drawing.Point(1132, 239);
            this.txtbox_YSize.Name = "txtbox_YSize";
            this.txtbox_YSize.Size = new System.Drawing.Size(43, 20);
            this.txtbox_YSize.TabIndex = 6;
            this.txtbox_YSize.TextChanged += new System.EventHandler(this.txtbox_YSize_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1115, 242);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(12, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "x";
            // 
            // chkbox_32x32
            // 
            this.chkbox_32x32.AutoSize = true;
            this.chkbox_32x32.Location = new System.Drawing.Point(1091, 193);
            this.chkbox_32x32.Name = "chkbox_32x32";
            this.chkbox_32x32.Size = new System.Drawing.Size(55, 17);
            this.chkbox_32x32.TabIndex = 8;
            this.chkbox_32x32.Text = "32x32";
            this.chkbox_32x32.UseVisualStyleBackColor = true;
            this.chkbox_32x32.CheckedChanged += new System.EventHandler(this.chkbox_32x32_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label2.Location = new System.Drawing.Point(1088, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 17);
            this.label2.TabIndex = 9;
            this.label2.Text = "גודל לוח";
            // 
            // chkbox_Easy
            // 
            this.chkbox_Easy.AutoSize = true;
            this.chkbox_Easy.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.chkbox_Easy.Location = new System.Drawing.Point(1039, 302);
            this.chkbox_Easy.Name = "chkbox_Easy";
            this.chkbox_Easy.Size = new System.Drawing.Size(37, 17);
            this.chkbox_Easy.TabIndex = 10;
            this.chkbox_Easy.Text = "קל";
            this.chkbox_Easy.UseVisualStyleBackColor = true;
            this.chkbox_Easy.CheckedChanged += new System.EventHandler(this.chkbox_Easy_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label3.Location = new System.Drawing.Point(1084, 273);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 17);
            this.label3.TabIndex = 11;
            this.label3.Text = "כמות מוקשים";
            // 
            // chkbox_Normal
            // 
            this.chkbox_Normal.AutoSize = true;
            this.chkbox_Normal.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.chkbox_Normal.Location = new System.Drawing.Point(1039, 325);
            this.chkbox_Normal.Name = "chkbox_Normal";
            this.chkbox_Normal.Size = new System.Drawing.Size(49, 17);
            this.chkbox_Normal.TabIndex = 12;
            this.chkbox_Normal.Text = "בינוני";
            this.chkbox_Normal.UseVisualStyleBackColor = true;
            this.chkbox_Normal.CheckedChanged += new System.EventHandler(this.chkbox_Normal_CheckedChanged);
            // 
            // chkbox_Hard
            // 
            this.chkbox_Hard.AutoSize = true;
            this.chkbox_Hard.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.chkbox_Hard.Location = new System.Drawing.Point(1039, 348);
            this.chkbox_Hard.Name = "chkbox_Hard";
            this.chkbox_Hard.Size = new System.Drawing.Size(45, 17);
            this.chkbox_Hard.TabIndex = 13;
            this.chkbox_Hard.Text = "קשה";
            this.chkbox_Hard.UseVisualStyleBackColor = true;
            this.chkbox_Hard.CheckedChanged += new System.EventHandler(this.chkbox_Hard_CheckedChanged);
            // 
            // chkbox_CustomAmount
            // 
            this.chkbox_CustomAmount.AutoSize = true;
            this.chkbox_CustomAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.chkbox_CustomAmount.Location = new System.Drawing.Point(1038, 371);
            this.chkbox_CustomAmount.Name = "chkbox_CustomAmount";
            this.chkbox_CustomAmount.Size = new System.Drawing.Size(69, 17);
            this.chkbox_CustomAmount.TabIndex = 14;
            this.chkbox_CustomAmount.Text = "כמות שונה";
            this.chkbox_CustomAmount.UseVisualStyleBackColor = true;
            this.chkbox_CustomAmount.CheckedChanged += new System.EventHandler(this.chkbox_CustomAmount_CheckedChanged);
            // 
            // txtbox_MineAmount
            // 
            this.txtbox_MineAmount.Location = new System.Drawing.Point(1054, 394);
            this.txtbox_MineAmount.Name = "txtbox_MineAmount";
            this.txtbox_MineAmount.Size = new System.Drawing.Size(73, 20);
            this.txtbox_MineAmount.TabIndex = 15;
            this.txtbox_MineAmount.TextChanged += new System.EventHandler(this.txtbox_MineAmount_TextChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1021, 584);
            this.panel1.TabIndex = 16;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label4.Location = new System.Drawing.Point(1171, 457);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 17);
            this.label4.TabIndex = 17;
            this.label4.Text = ":זמן";
            // 
            // txtbox_Seconds
            // 
            this.txtbox_Seconds.Enabled = false;
            this.txtbox_Seconds.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.txtbox_Seconds.Location = new System.Drawing.Point(1114, 446);
            this.txtbox_Seconds.Multiline = true;
            this.txtbox_Seconds.Name = "txtbox_Seconds";
            this.txtbox_Seconds.Size = new System.Drawing.Size(56, 44);
            this.txtbox_Seconds.TabIndex = 18;
            this.txtbox_Seconds.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtbox_Minutes
            // 
            this.txtbox_Minutes.Enabled = false;
            this.txtbox_Minutes.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.txtbox_Minutes.Location = new System.Drawing.Point(1038, 446);
            this.txtbox_Minutes.Multiline = true;
            this.txtbox_Minutes.Name = "txtbox_Minutes";
            this.txtbox_Minutes.Size = new System.Drawing.Size(56, 44);
            this.txtbox_Minutes.TabIndex = 19;
            this.txtbox_Minutes.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label5.Location = new System.Drawing.Point(1095, 454);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(19, 25);
            this.label5.TabIndex = 20;
            this.label5.Text = ":";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label6.Location = new System.Drawing.Point(1155, 541);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 17);
            this.label6.TabIndex = 21;
            this.label6.Text = ":דגלים";
            // 
            // txtbox_Flags
            // 
            this.txtbox_Flags.Enabled = false;
            this.txtbox_Flags.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.txtbox_Flags.Location = new System.Drawing.Point(1058, 514);
            this.txtbox_Flags.Multiline = true;
            this.txtbox_Flags.Name = "txtbox_Flags";
            this.txtbox_Flags.Size = new System.Drawing.Size(88, 67);
            this.txtbox_Flags.TabIndex = 22;
            this.txtbox_Flags.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(189)))), ((int)(((byte)(248)))));
            this.ClientSize = new System.Drawing.Size(1208, 608);
            this.Controls.Add(this.txtbox_Flags);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtbox_Minutes);
            this.Controls.Add(this.txtbox_Seconds);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtbox_MineAmount);
            this.Controls.Add(this.chkbox_CustomAmount);
            this.Controls.Add(this.chkbox_Hard);
            this.Controls.Add(this.chkbox_Normal);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.chkbox_Easy);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.chkbox_32x32);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtbox_YSize);
            this.Controls.Add(this.txtbox_XSize);
            this.Controls.Add(this.chkbox_CustomSize);
            this.Controls.Add(this.chkbox_24x24);
            this.Controls.Add(this.chkbox_16x16);
            this.Controls.Add(this.chkbox_8x8);
            this.Controls.Add(this.btn_StartGame);
            this.Name = "Form1";
            this.Text = "MineSweeper";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_StartGame;
        private System.Windows.Forms.CheckBox chkbox_8x8;
        private System.Windows.Forms.CheckBox chkbox_16x16;
        private System.Windows.Forms.CheckBox chkbox_24x24;
        private System.Windows.Forms.CheckBox chkbox_CustomSize;
        private System.Windows.Forms.TextBox txtbox_XSize;
        private System.Windows.Forms.TextBox txtbox_YSize;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox chkbox_32x32;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox chkbox_Easy;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox chkbox_Normal;
        private System.Windows.Forms.CheckBox chkbox_Hard;
        private System.Windows.Forms.CheckBox chkbox_CustomAmount;
        private System.Windows.Forms.TextBox txtbox_MineAmount;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtbox_Seconds;
        private System.Windows.Forms.TextBox txtbox_Minutes;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtbox_Flags;
        private System.Windows.Forms.Timer timer1;
    }
}

